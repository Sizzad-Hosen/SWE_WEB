import React, { useState } from "react";

import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

type Props = {
  activity: {
    prompt: string;

    pairs: {
      emoji: string;
      word: string;
    }[];
  };
};

export default function MatchingActivity({ activity }: Props) {
  const [selected, setSelected] = useState<number | null>(null);

  const [matched, setMatched] = useState<number[]>([]);

  function select(index: number) {
    if (selected === null) {
      setSelected(index);

      return;
    }

    if (selected === index) {
      setSelected(null);

      return;
    }

    setMatched([...matched, selected]);

    setSelected(null);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{activity.prompt}</Text>

      {activity.pairs.map((item, index) => (
        <TouchableOpacity
          key={index}
          style={[styles.card, matched.includes(index) && styles.done]}
          onPress={() => select(index)}
        >
          <Text style={styles.emoji}>{item.emoji}</Text>

          <Text style={styles.word}>
            {matched.includes(index) ? item.word : "?"}
          </Text>
        </TouchableOpacity>
      ))}

      {matched.length === activity.pairs.length && (
        <Text style={styles.success}>🎉 সব মিলেছে!</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,

    alignItems: "center",
  },

  title: {
    fontSize: 24,

    fontWeight: "700",

    marginBottom: 20,
  },

  card: {
    flexDirection: "row",

    backgroundColor: "#F1F1F1",

    padding: 20,

    borderRadius: 20,

    marginBottom: 12,

    width: 260,

    justifyContent: "center",
  },

  done: {
    backgroundColor: "#95D5B2",
  },

  emoji: {
    fontSize: 45,

    marginRight: 20,
  },

  word: {
    fontSize: 25,

    fontWeight: "bold",
  },

  success: {
    fontSize: 25,

    color: "green",

    marginTop: 25,
  },
});
