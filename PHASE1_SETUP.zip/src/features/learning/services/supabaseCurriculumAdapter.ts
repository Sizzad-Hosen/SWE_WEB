import type {
  Activity,
  CurriculumChapter,
} from "../data/curriculum";

import type {
  SupabaseCurriculumChapter,
  SupabaseLessonActivity,
  SupabaseQuizQuestion,
} from "../types/supabaseCurriculum";

type AdapterOptions = {
  nextChapterId?: string;
  chapterIcon?: string;
};

export function adaptSupabaseChapter(
  chapter: SupabaseCurriculumChapter,
  options: AdapterOptions = {}
): CurriculumChapter {

  const orderedActivities = [...chapter.lesson_activities].sort(
    (a, b) => a.order_index - b.order_index
  );

  const activities = orderedActivities.flatMap((activity) =>
    adaptActivity(chapter, activity)
  );

  return {
    id: chapter.id,
    title: chapter.title_bn,
    subtitle:
      chapter.summary_bn ??
      `পাঠ ${chapter.chapter_number}`,
    icon: options.chapterIcon ?? "📘",
    nextChapterId: options.nextChapterId,
    activities,
  };
}


function adaptActivity(
  chapter: SupabaseCurriculumChapter,
  activity: SupabaseLessonActivity
): Activity[] {

  const title =
    activity.title_bn ??
    activity.title_en ??
    "শেখার কাজ";


  const instruction =
    activity.instruction_bn ??
    activity.instruction_en ??
    "";


  switch(activity.activity_type){
    case 'story_snippet': {
    console.log(
  "STORY PAYLOAD:",
  JSON.stringify(activity.payload, null, 2)
);  
  const slides = Array.isArray(activity.payload.slides)
    ? (activity.payload.slides as any[])
    : [];

  if (slides.length > 0) {
    return slides.map((slide, index) => ({
      id: `${activity.id}-${slide.id ?? index + 1}`,
      type: 'snippet' as const,
      title,
      imageEmoji: slide.emoji ?? '📖',
      lines: Array.isArray(slide.line)
        ? slide.line
        : slide.text_bn
        ? [slide.text_bn]
        : [],
    }));
  }

  return [
    {
      id: activity.id,
      type: 'snippet' as const,
      title,
      imageEmoji: slides[0]?.emoji ?? '📖',
      lines: [],
    },
  ];
}
    case "letter":

      return [
        {
          id:activity.id,
          type:"letter",
          letter:activity.payload.letter,
          sound:
            activity.payload.sound ??
            activity.payload.letter,

          examples:
            (activity.payload.examples ?? [])
            .map((item)=>({
              emoji:item.emoji ?? "🖼️",
              word:item.word_bn ?? ""
            }))
        }
      ];



    case "word_build":

      return [
        {
          id:activity.id,
          type:"word_build",

          prompt:
            instruction || title,

          letters:
            activity.payload.letters ?? [],

          answer:
            activity.payload.answer ?? ""
        }
      ];



    case "picture_choice":

      return [
        {
          id:activity.id,

          type:"picture_choice",

          question:
            activity.payload.question,

          options:
            (activity.payload.options ?? [])
            .map((item)=>({
              emoji:item.emoji ?? "🖼️",
              label:
                item.label_bn ??
                ""
            })),

          answer:
            activity.payload.answer ?? 0
        }
      ];



    case "multiple_choice":

      return adaptQuizQuestions(
        chapter.quiz_questions
      );



    default:

      return [];

  }

}



function adaptQuizQuestions(
  questions: SupabaseQuizQuestion[]
): Activity[] {


  return [...questions]

    .sort(
      (a,b)=>
        a.order_index -
        b.order_index
    )


    .flatMap((question):Activity[]=>{


      const options =
        [...question.quiz_options]
        .sort(
          (a,b)=>
            a.option_order -
            b.option_order
        );


      const correctAnswer =
        options.findIndex(
          (option)=>
            option.is_correct
        );


      if(
        correctAnswer < 0 ||
        options.length < 2
      ){
        return [];
      }


      return [
        {

          id:question.id,

          type:"quiz",

          question:
            question.question_bn,

          options:
            options.map(
              option=>
                option.label_bn ??
                option.label_en ??
                ""
            ),

          answer:
            correctAnswer,


          hint:
            question.explanation_bn ??
            "আবার চেষ্টা করো।"

        }
      ];

    });

}